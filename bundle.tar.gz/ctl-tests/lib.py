"""Helpers for the control-layer tests: MinIO (one bucket per test module), a mongo-server process that can be
killed with SIGKILL, the admin HTTP client, and independent bucket listing through boto3 (not through the server)."""
import json
import os

# The engine has no built-in S3 settings: MinIO of the tests, explicit (same values as tools/minio-env.sh). They replace any AWS_* already in the environment: a test must never talk to MinIO with real credentials, nor to real S3 with these.
for _k, _v in {"AWS_ACCESS_KEY_ID": "minioadmin", "AWS_SECRET_ACCESS_KEY": "minioadmin", "AWS_REGION": "us-east-1", "AWS_ENDPOINT": "http://127.0.0.1:9000", "AWS_ALLOW_HTTP": "true"}.items():
    os.environ[_k] = _v
for _k in ("AWS_SESSION_TOKEN", "AWS_PROFILE", "AWS_WEB_IDENTITY_TOKEN_FILE", "AWS_ROLE_ARN", "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI", "AWS_CONTAINER_CREDENTIALS_FULL_URI"):
    os.environ.pop(_k, None)
import random
import signal
import subprocess
import time
import urllib.request
import urllib.error

import boto3
from botocore.config import Config

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.environ.get("MONGO_SERVER_BIN", os.path.join(ROOT, "target", "release", "mongo-server"))
OUT = os.path.join(ROOT, "ctl-tests", "out")
MINIO = os.environ.get("MINIO_ENDPOINT", "http://127.0.0.1:9000")
TOKEN = "test-token-0123456789abcdef"

os.makedirs(OUT, exist_ok=True)


def s3():
    return boto3.client("s3", endpoint_url=MINIO, aws_access_key_id="minioadmin", aws_secret_access_key="minioadmin",
                        region_name="us-east-1", config=Config(retries={"max_attempts": 3}))


def make_bucket(tag):
    name = f"ctl-{tag}-{os.urandom(4).hex()}".lower().replace("_", "-")  # not `random`: tests seed it
    s3().create_bucket(Bucket=name)
    return name


def list_prefix(bucket, prefix):
    """Every object under a prefix, listed directly from MinIO: [(key, size)]."""
    out = []
    pg = s3().get_paginator("list_objects_v2")
    for page in pg.paginate(Bucket=bucket, Prefix=prefix):
        for o in page.get("Contents", []):
            out.append((o["Key"], o["Size"]))
    return out


def prefix_bytes(bucket, prefix):
    return sum(sz for _, sz in list_prefix(bucket, prefix))


def free_port():
    while True:
        p = random.SystemRandom().randrange(20000, 40000)
        try:
            import socket
            s = socket.socket()
            s.bind(("127.0.0.1", p))
            s.close()
            return p
        except OSError:
            continue


class Server:
    def __init__(self, bucket, tag="srv", idle=60, extra=(), holder=None, port=None, admin_port=None, env=None, endpoint=None, admin=True, binary=None, nofile=None):
        self.admin_enabled, self.binary = admin, binary or BIN
        self.nofile = nofile          # open-files limit (soft and hard) of the server process, for the network-limit tests
        self.bucket, self.tag, self.idle, self.extra = bucket, tag, idle, list(extra)
        self.endpoint = endpoint or MINIO
        self.port = port or free_port()
        self.admin_port = admin_port or free_port()
        self.holder = holder or f"{tag}-{self.port}"
        self.proc = None
        self.log_path = os.path.join(OUT, f"{tag}-{self.port}.log")
        self.env = env or {}
        # CTL_TEST_AUTH=1: run the server with --auth and give the tests an authenticated client (root created through the localhost
        # exception), to run the whole control-layer suite with access control on. Servers a test starts with its own --auth are left alone.
        self.auth = os.environ.get("CTL_TEST_AUTH") == "1" and "--auth" not in self.extra

    def start(self, wait=True):
        cmd = [self.binary, "--listen", f"127.0.0.1:{self.port}"] + (["--admin-listen", f"127.0.0.1:{self.admin_port}"] if self.admin_enabled else []) + [
               "--idle-secs", str(self.idle), "--bucket", self.bucket, "--endpoint", self.endpoint, "--holder", self.holder,
               "--no-ttl"] + ([] if "--lease-ttl-secs" in self.extra else ["--lease-ttl-secs", "6"]) + (["--auth"] if self.auth else []) + self.extra
        env = dict(os.environ, MONGO_ADMIN_TOKEN=TOKEN, **self.env)
        if "--unsafe-skip-ownership-checks" in cmd:
            env["MONGO_ALLOW_UNSAFE_TEST_FLAGS"] = "1"      # negative controls only
        self.log = open(self.log_path, "ab")
        pre = None
        if self.nofile:
            import resource
            n = self.nofile
            pre = lambda: resource.setrlimit(resource.RLIMIT_NOFILE, (n, n))
        self.proc = subprocess.Popen(cmd, stdout=self.log, stderr=self.log, env=env, preexec_fn=pre)
        if wait:
            self.wait_ready()
        return self

    def ensure_root(self):
        """With CTL_TEST_AUTH=1: create the root user through the localhost exception (a restart finds it already there)."""
        if not self.auth:
            return
        from pymongo import MongoClient
        from pymongo.errors import OperationFailure
        c = MongoClient(f"mongodb://127.0.0.1:{self.port}/?directConnection=true", serverSelectionTimeoutMS=20000)
        try:
            c.admin.command("createUser", "root", pwd="rootpw", roles=[{"role": "root", "db": "admin"}])
        except OperationFailure:
            pass          # already created by an earlier start of this server
        finally:
            c.close()

    def wait_ready(self, timeout=30):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.proc.poll() is not None:
                raise RuntimeError(f"server exited with {self.proc.returncode}; see {self.log_path}")
            try:
                if self.admin_enabled:
                    self.admin.get("/v1/health")
                import socket
                socket.create_connection(("127.0.0.1", self.port), timeout=1).close()
            except Exception:
                time.sleep(0.1)
                continue
            self.ensure_root()
            return
        raise RuntimeError("server did not start")

    @property
    def admin(self):
        return Admin(f"http://127.0.0.1:{self.admin_port}")

    @property
    def uri(self):
        if self.auth:
            return f"mongodb://root:rootpw@127.0.0.1:{self.port}/?directConnection=true&authSource=admin"
        return f"mongodb://127.0.0.1:{self.port}/?directConnection=true"

    def client(self, **kw):
        from pymongo import MongoClient
        return MongoClient(self.uri, serverSelectionTimeoutMS=20000, socketTimeoutMS=120000, **kw)

    def kill9(self):
        if self.proc and self.proc.poll() is None:
            self.proc.send_signal(signal.SIGKILL)
            self.proc.wait()

    def term(self, timeout=60):
        if self.proc and self.proc.poll() is None:
            self.proc.send_signal(signal.SIGTERM)
            try:
                self.proc.wait(timeout)
            except subprocess.TimeoutExpired:
                self.proc.kill()

    def restart(self):
        self.term()
        self.proc = None
        return self.start()

    def log_text(self):
        with open(self.log_path, "rb") as f:
            return f.read().decode("utf8", "replace")


class Admin:
    def __init__(self, base, token=TOKEN):
        self.base, self.token = base, token

    def call(self, method, path, body=None, token="default", raw=False, headers=None, timeout=300):
        tok = self.token if token == "default" else token
        h = dict(headers or {})
        if tok is not None:
            h["Authorization"] = f"Bearer {tok}"
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            h["Content-Type"] = "application/json"
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                payload = r.read()
                if raw:
                    return r.status, payload, dict(r.headers)
                return r.status, (json.loads(payload) if payload else None)
        except urllib.error.HTTPError as e:
            payload = e.read()
            if raw:
                return e.code, payload, dict(e.headers)
            try:
                return e.code, json.loads(payload)
            except Exception:
                return e.code, {"raw": payload.decode("utf8", "replace")}

    def get(self, path, **kw):
        return self.call("GET", path, **kw)

    def post(self, path, body=None, **kw):
        return self.call("POST", path, body if body is not None else {}, **kw)

    def put(self, path, body=None, **kw):
        return self.call("PUT", path, body if body is not None else {}, **kw)

    def delete(self, path, **kw):
        return self.call("DELETE", path, **kw)


def fill(client, db, coll, n, start=0, batch=2000, extra=None):
    docs = []
    c = client[db][coll]
    for i in range(start, start + n):
        d = {"_id": i, "n": i, "grp": i % 10, "name": f"user{i}", "pad": "x" * 100}
        if extra:
            d.update(extra)
        docs.append(d)
        if len(docs) >= batch:
            c.insert_many(docs)
            docs = []
    if docs:
        c.insert_many(docs)


def dump_db(client, db):
    """Every document of every collection of a database, as {coll: {_id: doc}} (for equality checks)."""
    out = {}
    for cn in sorted(client[db].list_collection_names()):
        out[cn] = {repr(d["_id"]): d for d in client[db][cn].find({})}
    return out


def wait_until(fn, timeout=30, every=0.2, what="condition"):
    t0 = time.time()
    last = None
    while time.time() - t0 < timeout:
        try:
            last = fn()
            if last:
                return last
        except Exception as e:  # noqa
            last = e
        time.sleep(every)
    raise AssertionError(f"timed out waiting for {what}: {last}")
